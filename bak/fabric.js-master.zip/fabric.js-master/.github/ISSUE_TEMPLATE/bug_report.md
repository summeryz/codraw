---
name: Bug report
about: Create a report with a reproducible test case in a JSFIDDLE

---

<!-- BUG TEMPLATE -->
## Version
2.4.0

## Test Case
http://jsfiddle.net/fabricjs/Da7SP/

## Information about environment
Nodejs or browser?
Which browsers?

## Steps to reproduce

## Expected Behavior

## Actual Behavior
