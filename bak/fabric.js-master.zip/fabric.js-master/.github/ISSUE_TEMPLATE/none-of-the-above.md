---
name: None of the above
about: Report an issue that does not fit in any category

---

<!--
READ BEFORE PROCEEDING

You need to know that this is a project mantained by a very small team, of 1 person.
If you choose to open a generic issue without a template it will be categorized as low priority, and if is not interesting will be probably closed without an answer.
Issue failing to comply with the above templates will be closed too.
-->
